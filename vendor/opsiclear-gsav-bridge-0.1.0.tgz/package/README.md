# @opsiclear/gsav-bridge

Shared bridge protocol contracts between an OpsiClear shell and an embedded
GSAV player surface.

This package owns only the dependency-free wire contract: message constants,
builders, validators, and TypeScript types for session auth, native player
commands, bridge readiness, route, capability, playback, frame, and error
events. Platform glue such as iframe or WebView injection, `window` message
listeners, origin allowlists, persistence, and Supabase session application
belongs in the consuming app.
